<?php


namespace Twilio\Exceptions;


class EnvironmentException extends TwilioException {

}